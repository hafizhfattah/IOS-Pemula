//
//  DetailResep.swift
//  Resep
//
//  Created by Macbook on 20/04/21.
//

import SwiftUI

struct DetailResep: View {

    let makanboss : resep

    var body: some View {
        ZStack{
        VStack (alignment: .leading) {
            Image(makanboss.gambar)
                .resizable()
                .frame(width: 350, height: 220)
                .cornerRadius(10) 

            Text(makanboss.namamenu)
                .font(.title3)
                .fontWeight(.semibold)
                .foregroundColor(.orange)
                .padding(.leading, 12)
            Text(makanboss.sumber)
                .foregroundColor(.secondary)
                .font(.subheadline)
                .padding(.leading, 12)

        }.frame(width: 342, height: 285)
        .background(Color.gray.opacity(0.3))
        .cornerRadius(15)
        }

        ScrollView{
            VStack (alignment: .leading) {
                Text(makanboss.bahan)
                    .multilineTextAlignment(.leading)
                .frame(width: 330.0)
                .padding(.bottom, 10)


            }.padding()
        }

    }

}

struct DetailResep_Previews: PreviewProvider {
    static var previews: some View {
        DetailResep(makanboss: resep(id: 0, gambar:"", namamenu:"", sumber: "", bahan:""))
            .preferredColorScheme(.dark)
    }
}
