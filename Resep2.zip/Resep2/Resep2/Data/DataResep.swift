//
//  DataResep.swift
//  Resep
//
//  Created by Macbook on 20/04/21.
//

var dataresep = [
    
    resep(id: 0, gambar:"martabak" , namamenu:"Martabak Telor" , sumber:"@Kompas" ,bahan:
"""
Martabak identik sebagai camilan malam di Indonesia. Selain martabak manis, beberapa penjual martabak juga menjual martabak telur. Martabak telur yang dijual malam hari berbeda dengan martabak telur jajanan pasar. Sebab kulit martabak telur harus dibikin sendiri.

Sementara martabak telur jajanan pasar kulitnya kebanyakan dari kulit lumpia. Berikut resep martabak telur dari Sajian Sedap, kamu bisa masak menggunakan teflon di rumah.

Bahan:
- 200 gram tepung terigu protein tinggi
- 1/4 sendok teh garam
- 140 ml air
- 30 gram minyak goreng
- 500 ml minyak goreng untuk merendam
- 500 ml minyak untuk menggoreng

Lanjutanya:
- 500 gram daging giling
- 100 gram ayam giling
- 3 siung bawang putih iris tipis
- 6 butir bawang merah, iris tipis
- 2 buah cabai merah, cincang halus
- 2 sendok teh kari bubuk
- 1 sendok teh garam
- 1/4 sendok teh merica bubuk
- 1/2 sendok teh gula pasir 1
- batang daun bawang, diiris halus
- 1 sendok makan minyak untuk menumis
- Bahan campuran per porsi (aduk rata):
- 25 gram daun bawang, iris halus
- 1 butir telur bebek, kocok lepas
- 1 butir telur ayam, kocok lepas
- 1/2 buah (50 gram) bawang bombay, cicang halus
- 1/4 sendok teh garam
- 1/8 sendok teh merica bubuk
- 50 gram bahan tumisan daging

1. Buat kulit martabak terlebih dahulu, campur tepung terigu dan garam. Tuang air sedikit demi sedikit sambil diuleni sampai kalis. Tambahkan minyak goreng. Uleni sampai elastis.
2. Timbang masing-masing 75 gram. Bulatkan. rendam dalam minyak goreng selama dua jam.
3. Buat isian martabak, tumis bawang putih, bawang merah, dan cabai merah sampai harum. Tambahkan daging giling dan ayam giling. Aduk sampai berubah warna.
4. Masukkan kari bubuk, garam, merica bubuk, dan gula pasir. Aduk sampai meresap. Tambahkan daun bawang. Aduk rata. Sisihkan.
5. Pipihkan kulit dan giling tipis. Sisihkan.
6. Panaskan minyak dalam teflon. Letakkan selembar kulit. Beri campuran isi. Lipat. Goreng dengan sedikit minyak (jangan sampai terendam) sambil disiram-siram minyak sampai matang.
"""),

    resep(id: 1, gambar:"piscok" , namamenu:"Piscok Meler" , sumber:"@Cookpad" ,bahan:
"""
Bahan-bahan
- 2 sisir pisang Uli /Bisa apa saja yg penting pisang hrs matang
- 2 gulung kulit Lumpia
- 2 bungkus meses coklat/ Chocolatos coklat
- 50 grm gula pasir
- 4 sdm margarin
- Bahan perekat / Lem :
- 2 sdm tepung terigu
- 50 ml air suhu ruang

Langkah:

1.Siapkan bahan dulu,Lalu kupas pisang dan belah menjadi 2 bagian memanjang lalu panaskan wajan / Teflon tambahkan margarin lalu tumis pisang hingga berubah warna.
2.Seperti ini hasilnya setelah ditumis pisang nya.Bisa juga langsung di goreng dengan minyak banyak, Hasilnya akan sedikit berminyak tapi sama saja rasanya (Silahkan saja ikutin cara yg bunda suka ya...)
3.Siapkan terigu + 50 ml air aduk rata buat perekat pinggir dari kulit lumpia nya.
4.Ambil 1 lembar kulit lumpia isi dengan 1 potong pisang yg sudah ditumis tadi, Tambahkan 1 sdm meses dan 1/2 sdt gula pasir (bisa juga ditambah 1 sdt chocolatos) lem pinggirnya dengan bahan perekat tadi lalu lipat dan gulung seperti pada gambar saya. Oh ya penambahan gula pasir disini supaya pas di goreng gulanya akan menjadi karamel, dan itu yang membuat piscok ini jadi Enak.
5.Lakukan hingga semua tergulung dengan rapi.Lalu goreng dengan minyak banyak dan api sedang saja biar tidak cepat hangus.
6.Tiriskan dengan di alas kertas Bungkus / Tissue dapur untuk menyerap minyak nya. Lalu sajikan......Manis, Kriuk meleleh coklatnya. Oh ya meses bisa di ganti Dcc lebih Enak lagi kalau buat di makan sendiri. Berhubung buat jualan jadi saya pake meses saja biar lebih irit.

"""),
    
    resep(id: 2, gambar:"molen" , namamenu:"Molen Lezat" , sumber:"@Cookpad" ,bahan:
"""
Bahan-bahan:
(40 biji)
- 1 kg pisang tanduk (bebas)
- 500 gr terigu segitiga
- 50 gr maizena
- 20 gr susu bubuk full cream
- 100 gr gula halus
- 1/2 St baking soda
- 100 gr margarine
± 150 gr Air
- 1/2 St garam
- 1 butir telur

Langkah:
1.Masak air, garam dan margarine, hingga mencair, lalu dinginkan
2.Campur dan ayak terigu, maizena dan susu bubuk
3.Masukkan gula halus, aduk sampai benar-benar tercampur kemudian masukkan margarin cair lalu aduk pakai spatula
4.Uleni sampai adonan benar kalis sisihkan
5.Ambil pisang, kupas lalu potong 2 kemudian belah menjadi 4 bagian
6.Ambil adonan, gilas sampai ketebalan yang sesuai dengan selera, kemudian lilitkan ke pisang
7.Lakukan sampai adonan dan pisang habis, panaskan minyak, goreng molen sampai kuning keemasan angkat tiriskan, gunakan api sedang cendrung kecil
8.Sajikan bersama teh hangat
"""),
    
    resep(id: 3, gambar:"espisangijo" , namamenu:"Es Pisang Ijo" , sumber:"@Cookpad" ,bahan:
"""
Bahan-bahan:
🍧Bahan Pisang Ijo :
- 10 Buah Pisang Kepok/Pisang Tanduk/Pisang Nangka
- 600 Ml Air
- 150 Gram Tepung Beras
- 150 Gram Tepung Terigu
- 60 Gram Gula Pasir
- 65 Ml Santan Kental Instan
- 1/2 Sdt Garam
- Secukupnya Pasta Pandan
🍧Bahan Bubur Sumsum :
- 750 Ml Air
- 100 Gram Tepung Beras
- 65 Ml Santan Kental Instan
- 1/2 Sdt Garam
- 2 Lembar Daun Pandan
🍧Bahan Saus Santan :
- 65 Ml Santan Kental Instan
- 500 Ml Air
- 2 Lembar Daun Pandan
- 2 Sdm Tepung Maizena
- 1/2 Sdt Garam
🍧Bahan Pelengkap :
- Secukupnya Sirup DHT Pisang Ambon/Cocopandan
- Secukupnya Susu Kental Manis
🍧Langkah:
- Kukus Pisang Dengan Kulitnya selama 15 menit.Angkat,Dinginkan.
- Campur didalam wadah tepung terigu,tepung beras,gula pasir,garam,santan kental dan air.Aduk Merata,lalu beri pasta pandan secukupnya.
- Saring adonan kulit agar terpisah dari gerindil.Lalu masak dengan api kecil hingga matang.Selama proses pemasakan harus terus diaduk ya.Matang,Angkat
- Siapkan plastik,olesi tipis dengan minyak sayur.Lalu ambil adonan kulit sekitar 1-2 sdm,pipihkan.
- Beri 1 buah pisang,lalu tutup semua permukaan pisang dengan adonan kulit.Lakukan hingga habis,Kukus dengan api sedang cenderung kecil selama 20 menit.Jika Takut Menempel,kalian bisa bungkus terlebih dahulu dengan daun pisang.Angkat Dinginkan.
- Membuat Bubur Sumsum,Masukan semua bahan bubur sumsum kedalam panci aduk rata.Lalu Masak Dengan Api kecil hingga matang (harus terus diaduk selama proses masak).Cirinya sudah matang mengental dan banyak letupan.Angkat Dinginkan.Bisa Kalian Masukan Kedalam Kulkas Dulu Ya Pisang Ijo nya.
- Membuat Saus Santan : Masukan Semua Bahan Saus Santan Kedalam Panci,Lalu Masak Dengan Api Sedang Hingga Mendidih.Angkat Dinginkan.
- Jika Semua Bahan Sudah Dingin,Siap Untuk Penyajian.Potong Pisang Ijo Sesuai Selera.Siapkan Mangkuk Saji,Tuang Es Batu/Es Serut Secukupnya.
- Lalu Beri Bubur Sumsum secukupnya,Tata Pisang Ijo diatas Bubur Sumsum.Tambahkan Saus Santan Diatas Es.
- Kemudian Beri Sirup Cocopandan/DHT secukupnya dan Susu Kental Manis Secukupnya.Es Pisang Ijo Siap Dinikmati.
"""),
    resep(id: 4, gambar:"kepiting" , namamenu:"Kepiting Saos Padang" , sumber:"@Cookpad" ,bahan:
"""
Bahan-bahan
(Porsi 2-3 orang)
- 4 ekor kepiting
- 7 siung Bawang putih
- 10 siung bawang merah
- 1 bh bawang bombay
- 2 bh tomat merah
- 2 bh cabe merah besar
- 5 bh cabe rawit (opsional)
- 2 sdt merica bubuk
- Saos sambal, saos tiram, saos tomat, kecap manis
- Gula, garam, penyedap rasa
- Minyak goreng
- secukupnya Air
Langkah
- Cuci bersih kepiting, lalu rebus kepiting selama 15-30 menit hingga matang. Tanda kepiting sudah matang jika warna kepiting sudah berwarna orange ya bun. Angkat lalu tiriskan.
- Potong kepiting menjadi 2 bagian/sesuai selera.
- Siapkan bumbu
- Rajang bawang merah dan bawang putih, bawang bombay, potong cabe merah, cabe rawit, dan tomat
- Panaskan sedikit minyak goreng, tumis bawang"an dan cabe"an hingga harum lalu tambahkan saos"an dan air secukupnya. Lalu, tambahkan lada bubuk, gula, garam, dan penyedap rasa
- Masukkan potongan kepiting kedalam masakan, aduk rata, diamkan hingga bumbu meresap, jika dirasa pas, angkat dan kepiting saos padang siap disajikan
"""),
    
    resep(id: 5, gambar:"omlet" , namamenu:"Omelet Lembut ", sumber:"@Cookpad" ,bahan:
"""
Bahan-bahan:
(1 porsi)
- 1 butir Telur
- 3/4 sdt Maizena
- sesuai selera Tomat (potong dadu)
- sesuai selera Daun Bawang (diiris)
- sesuai selera garam, lada, penyedap
Langkah:
Kocok telur bersama tomat, daun bawang, garam, lada, penyedap, terakhir masukan maizena.
Masukan kocokan telur ke wajan dengan api kecil, diamkan tunggu setengah matang.
Omelet Telur Lembut ala Hotel langkah memasak 2 foto
Lipat telur perlahan, diamkan, kemudian angkat sesuai selera tingkat kematangan.
""")
]

