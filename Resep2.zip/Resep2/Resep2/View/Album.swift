//
//  Album.swift
//  Resep2
//
//  Created by Macbook on 22/04/21.
//

import SwiftUI

struct Album: View {
    var body: some View {
        
        
        ScrollView{
        
        VStack (alignment: .leading) {
            Image("Dafa Molor")
                .resizable()
                .frame(width: 350, height: 220)
                .cornerRadius(10)
            Image("Khalish Molor")
                .resizable()
                .frame(width: 350, height: 220)
                .cornerRadius(10)
            
            Image("gaja molor")
                .resizable()
                .frame(width: 350, height: 220)
                .cornerRadius(10)
            
            Image("Luthfi Molor")
                .resizable()
                .frame(width: 350, height: 220)
                .cornerRadius(10)
            
            Image("Ridho Molor")
                .resizable()
                .frame(width: 350, height: 220)
                .cornerRadius(10)
           
        }
        
          
            
        }
}

struct Album_Previews: PreviewProvider {
    static var previews: some View {
        Album()
            .preferredColorScheme(.dark)
    }
}

}
