//
//  MenuMakanan.swift
//  Resep2
//
//  Created by Macbook on 20/04/21.
//

import SwiftUI

struct MenuMakanan: View {
    var body: some View {
        ZStack{
            TabView{
                Resep2()
                    .tabItem{
                        Image(systemName: "house.fill")
                        Text("Beranda")
                    }
                
                profil1()
                    .tabItem{
                        Image(systemName: "person.circle.fill")
                        Text("Profil")
                    }
                baru()
                    .tabItem{
                        Image(systemName: "paperplane")
                        Text("Detail Shop")
                    
                
            }
        }
    }
}
        struct zig_Previews: PreviewProvider {
            static var previews: some View {
                MenuMakanan()
                    .preferredColorScheme(.dark)
            }
        }
struct Resep2: View {
    var body: some View {
        NavigationView{
            
            ScrollView{
        ForEach(dataresep){Data in
        NavigationLink(
            destination: DetailResep(makanboss : Data)){
        ZStack {
            HStack{
            VStack (alignment: .leading) {
                        VStack (alignment: .leading) {
                            Image(Data.gambar)
                                .resizable()
                                .frame(width: 310, height: 200)
                                .cornerRadius(12)
                            
                            Text(Data.namamenu)
                                .font(.title3)
                                .fontWeight(.semibold)
                                .foregroundColor(.orange)
                                .padding(.leading, 12)
                            Text(Data.sumber)
                                .foregroundColor(.secondary)
                                .font(.subheadline)
                                .padding(.leading, 12)
                        }.frame(width: 320, height: 260)
                        .background(Color.gray.opacity(0.3))
                        .cornerRadius(12)
            }
                    
                }
            Image(systemName: "square.and.arrow.down")
                .foregroundColor(.orange)
                .font(.system(size: 30))
                .padding(.top,200)
                .padding(.leading,250)
            
            }.padding(11)
        .navigationTitle(Text("Beranda"))
        .navigationBarTitleDisplayMode(.inline)
        
        .navigationBarItems(leading: Image("").font(.system(size: 30)).foregroundColor(.blue))
            }
      
        }
            }
            }
        
        
    }
}
}

