//
//  profile.swift
//  IOSpemula_IDN
//
//  Created by macbook on 14/04/21.
//

import SwiftUI

        struct profileView_Previews: PreviewProvider {
            static var previews: some View {
                profil1()
                    .preferredColorScheme(.dark)
            }
        }
        
        struct profil1: View {
            var body: some View {
        NavigationView{
            Form{

                Section(){
                    
                    HStack{
                            NavigationLink(destination:profil()){
                        Image("oom")
                            .resizable()
                            .frame(width: 50, height: 50)
                            .clipShape(Circle())
                        VStack(alignment:.leading){
                            Text("FizFat")
                                .font(.headline)
                            Text("Anak Sholeh")
                                .font(.caption)
                        }
                        }
                    }
                    .padding(.top,10)
                    .padding(.bottom,10)
                    Section(header:Text("Setting")){
                        HStack{
                            Image(systemName: "person.fill")
                                .frame(width:35, height:35)
                                .foregroundColor(.white)
                            
                            Text("Akun")
                                                        
                        }
                        HStack{
                            NavigationLink(destination:baru()){
                            Image(systemName: "square.and.pencil")
                                    .frame(width:35, height:35)
                            Text("Detail Menu")
                                
                            }}
                        HStack{
                            NavigationLink(destination:Album()){
                            Image(systemName: "photo.fill")
                                .frame(width:35, height:35)
                            Text("Album")
                                
                            }}
                        HStack{
                            Image(systemName: "calendar")
                                .frame(width:35, height:35)
                            Text("Tanggal & Waktu ")
                                
                        }
                        HStack{
                            Image(systemName: "return")
                                .frame(width:35, height:35)
                            Text("Keluar")
                            }
                        
                    
                    
                    Spacer()
                    
                    Section(header: Text("Data Kamu")){
                        HStack{
                            Image(systemName: "heart")
                                .frame(width:35, height:35)
                                .background(Color.red)
                                .cornerRadius(10)
                                .foregroundColor(.white)
                            Text("Favorit")
                           
                        }
                        HStack{
                            NavigationLink(destination:Timerok()){
                            Image(systemName: "stopwatch")
                                    .frame(width:35, height:35)
                            Text("Timer & StopWatch")
                                
                            }}
                        HStack{
                                Image(systemName: "clock")
                                    .frame(width:35, height:35)
                                    .background(Color.blue)
                                    .cornerRadius(10)
                                    .foregroundColor(.white)
                                Text("History")
                            }
                        
                    }
                }
                }
            .navigationBarTitle("Profil")
            .navigationBarTitleDisplayMode(.inline)
            
                }
        }
           

        }
        }
