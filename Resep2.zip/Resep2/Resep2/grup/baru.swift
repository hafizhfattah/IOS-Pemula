//
//  baru.swift
//  Resep2
//
//  Created by Macbook on 22/04/21.
//

import SwiftUI
 


struct baru: View {
    
 
    private var gridItem = [GridItem(.flexible()),GridItem(.flexible()),]
 
    let data : [DataModel] = [
        DataModel(id: 0, namaproduk: "Rendang", fotoproduk: "rendang", hargaproduk: Int(50000), lokasi: "Padang", ratingcount: 5, jumlahrating: 56),
        DataModel(id: 1, namaproduk: "Sushi", fotoproduk: "sushi", hargaproduk: Int(40000), lokasi: "Jepang", ratingcount: 5, jumlahrating: 56),
            DataModel(id: 2, namaproduk: "Sate", fotoproduk: "sate00", hargaproduk: 20000, lokasi: "Depok", ratingcount: 5, jumlahrating: 56),
            DataModel(id: 3, namaproduk: "Dimsum", fotoproduk: "dimsum", hargaproduk: 35000, lokasi: "Thailand", ratingcount: 5, jumlahrating: 56),
            DataModel(id: 4, namaproduk: "Ice Cream", fotoproduk: "eskrim", hargaproduk: 20000, lokasi: "Amerika", ratingcount: 5, jumlahrating: 56),
            DataModel(id: 5, namaproduk: "Ramen", fotoproduk: "ramen", hargaproduk: 70000, lokasi: "Jepang", ratingcount: 5, jumlahrating: 56),
            DataModel(id: 6, namaproduk: "Bolu Gulung", fotoproduk: "bolu", hargaproduk: 15000, lokasi: "TangSel", ratingcount: 5, jumlahrating: 56),
            DataModel(id: 7, namaproduk: "Warteg ", fotoproduk: "warteg", hargaproduk: 10000, lokasi: "Rumah Teh Yuli", ratingcount: 5, jumlahrating: 56),
            
 
        ]
 
    @State var jumlahkeranjang: Int = 2
    
    var body: some View {
        NavigationView{
            ScrollView{
                LazyVGrid(columns: gridItem){
                    ForEach(data){ row in
                        VStack{
                            Product(data: row, jumlahproduk: self.$jumlahkeranjang)
                        }
                        .padding()
                        .frame(height:400)
 
                    }
                }
            }
            .navigationBarTitle("Best Food")
            .navigationBarItems(
                    trailing:
                        HStack{
                      
                            NavigationLink(destination:Timerok()){
                                Image(systemName: "stopwatch")
                                    .foregroundColor(.white)
                                    .frame(width: 50, height: 30)
                                
                            }
                            keranjangView(jumlah: self.$jumlahkeranjang)
                            }
                            
                        
            )
        }
 
    }
}
// keranjang
struct keranjangView : View {
    @Binding var jumlah: Int
 
    var body : some View {
        
        
        ZStack{                Image(systemName: "archivebox")
                    .resizable()
                    .foregroundColor(.white)
                    .frame(width:20, height:20)
 
            
            
            Text("\(jumlah)")
                .foregroundColor(Color.white)
                .frame(width:10, height:10)
                .font(.body)
                .padding(5)
                .background(Color.red)
                .clipShape(Circle())
                .offset(x:10,y:-10)
            
        }
    }
}
 
 
struct baru_Previews: PreviewProvider {
    static var previews: some View {
        
        ContentView()
            .preferredColorScheme(.dark)
    }
}
 
 
struct Product: View {
 
    let data: DataModel
 
    @Binding var jumlahproduk: Int
 
    var body: some View {
 
            VStack{
                //Foto
                VStack{
                    ZStack(alignment:.topTrailing){
                        Image(self.data.fotoProduk)
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .frame(width: 200, height: 200)
                            .cornerRadius(15)
                            .clipped()
                        Button(action: {print("OK")}){
                            Image(systemName: "heart.fill")
                                .padding()
                                .foregroundColor(Color.red)
                        }
 
 
                    }
 
                    VStack(alignment:.leading){
                        //Text
                        Text(self.data.namaProduk)
                            .font(.title3)
                            .bold()
                            .padding(.leading)
                            .padding(.trailing)
                        Text("Rp.\(self.data.hargaProduk)")
                            .font(.title3)
                            .foregroundColor(.orange)
                            .bold()
                            .padding(.leading)
                            .padding(.trailing)
 
                        HStack{
                            Image(systemName: "location.fill")
                            Text(self.data.lokasi)
                        }
                        .padding(.leading)
                        .padding(.trailing)
 
                        HStack{
                            HStack{
                                //Menghitung Bintang
                                ForEach(0..<self.data.ratingCount){
                                    items in
                                    Image(systemName: "star.fill")
                                        .foregroundColor(.orange)
                                }
                            }
                            .padding(.leading)
                            .padding(.trailing)
 
                        }
                    }
 
                    //buat komponen baru jumlah
                    //ambil data binding dari komponen tambahkeranjang
                    tambahKeranjang(jumlah: $jumlahproduk)
 
 
                }
                .background(Color("AccentColor"))
                .cornerRadius(15)
 
            }
            .padding()
    }
}
 
//button tambah keranjang
struct tambahKeranjang : View {
    //buat binding data
    @Binding var jumlah: Int
 
    var body : some View {
        Button(action: {self.jumlah += 1}){
            HStack{
                Spacer()
                HStack{
                    Image(systemName: "cart.badge.plus")
                    Text("Keranjang")
                        .font(.callout)
                        .padding()
                }
                Spacer()
 
            }
        }
        .background(Color.blue)
        .foregroundColor(Color.white)
        .cornerRadius(10)
        .padding(10)
    }
}
