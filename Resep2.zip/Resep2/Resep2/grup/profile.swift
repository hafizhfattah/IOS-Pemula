//
//  profile.swift
//  apk resep makan
//
//  Created by Macbook on 16/04/21.
//

import SwiftUI
struct profil: View {
    var body: some View {
        
        VStack {
            HStack {
                Spacer()
                
                VStack {
                    
                    Image("oom")
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                        .frame(width: 200, height: 200)
                        .clipShape(Circle())
                        .overlay(Circle().stroke(Color.orange, lineWidth: 4))
                        .padding(.top, 44)
                    
                    Text("Hafizh")
                        .font(.system(size: 20))
                        .bold()
                        .foregroundColor(.orange)
                        .padding(.top, 12)
                    
                    Text("@Fizfat")
                        .font(.system(size: 18))
                        .foregroundColor(.secondary)
                        .padding(.top, 4)
                }
                Spacer()
                
                
            }
            
        }
        
        ScrollView{
            VStack (alignment: .leading) {
                Text("""
                        Ronin (浪人 rōnin) atau rōshi adalah sebutan untuk samurai yang kehilangan atau terpisah dari tuannya pada zaman feodal Jepang (1185-1868). Samurai menjadi kehilangan tuannya akibat hak atas wilayah kekuasaan sang tuan dicabut oleh pemerintah. Samurai yang tidak lagi memiliki tuan tidak bisa lagi disebut sebagai samurai, karena samurai adalah "pelayan" bagi sang tuan.
                     
                        Dalam budaya populer, ronin didramatisasi sebagai samurai tak bertuan, hidup tak terikat pada tuan atau daimyo dan mengabdikan hidup dengan mengembara mencari jalan samurai yang sejati.

                        Di zaman Jepang kuno, ronin berarti orang yang terdaftar (memiliki koseki) sebagai penduduk di suatu tempat, tetapi hidup mengembara di wilayah lain sehingga dikenal juga dengan sebutan furō (pengembara).

                        Di zaman Muromachi dan zaman Kamakura, samurai yang kehilangan pekerjaan dan tempat tinggal menjadi pengembara. Pada waktu itu, ronin sering menjadi sebab timbulnya kerusuhan skala kecil di berbagai daerah. Walaupun para daimyo banyak membutuhkan prajurit untuk berperang, ronin hampir tidak berkesempatan mendapat majikan yang baru. Situasi keamanan yang buruk menyebabkan ronin membentuk komplotan yang saling berebut wilayah dan pengaruh, beroperasi sebagai gerombolan pencoleng hingga menimbulkan huru-hara.

                        Di zaman Edo, penghapusan sebagian besar daimyo mengakibatkan jumlah samurai yang menjadi ronin makin bertambah banyak. Di akhir pemerintahan Tokugawa Iemitsu, jumlah ronin melonjak menjadi sekitar 500.000 orang karena peran samurai tidak lagi dibutuhkan pada masa damai. Sebagian besar ronin menjadi penduduk kota atau menjadi petani, sebagian ronin bahkan pergi merantau ke luar negeri menjadi prajurit bayaran. Sebagian besar ronin justru hidup menderita dalam kemiskinan di kota-kota dan pemerintah Bakufu menganggapnya sebagai ancaman keamanan. Ronin banyak yang diusir dari kota dan hanya boleh tinggal di wilayah-wilayah yang ditentukan. Pemerintah Bakufu bahkan mengambil tindakan yang lebih kejam dengan melarang ronin mencari tuan yang baru. Kelompok ronin yang terusir ke sana ke mari akhirnya bersatu di bawah pimpinan Yui Shōsetsu dan berkomplot untuk menggulingkan pemerintah Bakufu dalam Pemberontakan Keian.

                        Pemerintah Bakufu melarang pengangkatan anak sebagai putra pewaris darurat (matsugoyōshi), akibatnya garis keturunan daimyo banyak yang terputus karena daimyo keburu meninggal tanpa memiliki putra pewaris. Keluarga daimyo yang tidak mempunyai putra pewaris terpaksa bubar dan samurai yang kehilangan tuannya berakhir sebagai ronin. Setelah pecahnya Pemberontakan Keian, pemerintah Bakufu berusaha memperbaiki kebijakan terhadap ronin. Pemerintah mengeluarkan berbagai kebijakan baru, seperti melonggarkan larangan mengangkat putra pewaris darurat, mengurangi jumlah daimyo yang dirampas wilayah kekuasaannya, dan meninjau kembali pembatasan wilayah permukiman ronin. Peluang ronin mencari majikan baru juga dibuka kembali. Walaupun sudah ada kebijakan baru, jumlah samurai yang menjadi ronin tidak juga bisa berkurang. Ronin-ronin baru terus bermunculan akibat perampasan wilayah kekuasaan para daimyo yang terus berlanjut.


                    
                """)
                    .multilineTextAlignment(.leading)
                .frame(width: 330.0)
                .padding(.bottom, 10)


            }.padding()
        }
    }
}
struct profile_Previews: PreviewProvider {
    static var previews: some View {
        profil()
            .preferredColorScheme(.dark)
    }
}
