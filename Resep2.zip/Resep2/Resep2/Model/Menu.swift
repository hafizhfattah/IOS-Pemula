//
//  Menu.swift
//  Resep
//
//  Created by Macbook on 20/04/21.
//

struct resep : Identifiable {
    let id : Int
    let gambar : String
    let namamenu : String
    let sumber : String
    let bahan : String
}
